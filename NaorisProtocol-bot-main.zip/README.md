# Naoris automation python bot

[![Static Badge](https://img.shields.io/badge/Telegram-Channel-Link?style=for-the-badge&logo=Telegram&logoColor=white&logoSize=auto&color=blue)](https://t.me/+pB6j65Kv7cdjZmU0)

# Recommendations before use:
- **Use python 3.10🐍**

# Features:
- **Auto add to whitelist**
- **Get stats for your accounts**
- **All types of proxy support**
- **Auto send ping**
- **Auto send initiate message production**
- **Auto activate protection**
- **Multithread**

## **Installation Methods:** 
For manual setup on Windows or macOS, follow the guide. macOS offers an alternative: a user-friendly [DMG file](../../releases).


# Installation+Run🕸

**Windows:**
```shell
git clone https://github.com/__USERNAME__/__REPONAME__
cd __REPONAME__
run.bat
```

**Linux/macOS:**
```shell
git clone https://github.com/__USERNAME__/__REPONAME__
cd __REPONAME__
chmod +x run.sh
./run.sh
```

# Set-up⚙
- **Accounts:** In the **accounts.json** file put your addresses and device hash in such format:
```shell
 [
      {
          "Address": "Address_1",
          "deviceHash": "Device_hash"
      },
      {
          "Address": "Address_2",
          "deviceHash": "Device_hash"
      }
  ]
```
- **Proxy:** in the **proxy.txt** file put your proxy in such format:
```shell
type://username:password:ip:port
http://username:password:ip:port
socks5://username:password:ip:port
```
  
## Contribution🌟

- ***Don't forget to put stars⭐***

- ***JOIN OUR TELEGRAM [CHAT](https://t.me/+9j5RcKMfT5s4M2Q0)***

- ***My eth address is 0xd260e28b533f153d59cb340b4213ad5977d71fe7***

If you have any questions or some ideas to improve my bots, feel free to contact me on telegram or issues section.